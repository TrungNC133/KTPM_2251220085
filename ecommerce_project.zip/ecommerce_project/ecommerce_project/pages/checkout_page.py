# pages/checkout_page.py
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage

class CheckoutPage(BasePage):
    FIRST_NAME = (By.ID, "first-name")
    LAST_NAME = (By.ID, "last-name")
    ZIP_CODE = (By.ID, "postal-code")
    CONTINUE_BUTTON = (By.ID, "continue")
    FINISH_BUTTON = (By.ID, "finish")
    ERROR_MESSAGE = (By.CSS_SELECTOR, "h3[data-test='error']")
    SUCCESS_MESSAGE = (By.CLASS_NAME, "complete-header")

    def fill_shipping_info(self, first="", last="", zip_code=""):
        # Dùng find_clickable + JS để đảm bảo field có thể nhập
        self._clear_and_type(self.FIRST_NAME, first)
        self._clear_and_type(self.LAST_NAME, last)
        self._clear_and_type(self.ZIP_CODE, zip_code)
        
        # Click Continue bằng JS nếu cần
        try:
            self.click(self.CONTINUE_BUTTON)
        except:
            self.driver.execute_script("document.querySelector('#continue').click();")

    def _clear_and_type(self, locator, text):
        """Helper để nhập text ổn định hơn"""
        try:
            field = self.find_clickable(locator)
            field.clear()
            field.send_keys(text)
        except:
            # Fallback: dùng JS để nhập
            js = f"""
            let el = document.querySelector('{locator[1]}');
            el.value = '';
            el.value = '{text}';
            el.dispatchEvent(new Event('input'));
            """
            self.driver.execute_script(js)

    def get_error_message(self):
        try:
            return self.find(self.ERROR_MESSAGE).text
        except TimeoutException:
            return ""

    def complete_checkout(self):
        try:
            self.click(self.FINISH_BUTTON)
        except:
            self.driver.execute_script("document.querySelector('#finish').click();")

    def get_success_message(self):
        try:
            return self.find(self.SUCCESS_MESSAGE).text
        except TimeoutException:
            return ""