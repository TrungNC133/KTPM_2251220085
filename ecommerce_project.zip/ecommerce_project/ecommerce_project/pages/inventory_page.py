# pages/inventory_page.py
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException  # ĐÃ THÊM
from pages.base_page import BasePage

class InventoryPage(BasePage):
    SORT_DROPDOWN = (By.CLASS_NAME, "product_sort_container")
    PRODUCT_NAME = (By.CLASS_NAME, "inventory_item_name")
    PRODUCT_PRICE = (By.CLASS_NAME, "inventory_item_price")

    ADD_TO_CART_BUTTONS = (By.XPATH, "//button[contains(@class, 'btn_primary') and contains(text(), 'Add')]")
    REMOVE_BUTTONS = (By.XPATH, "//button[contains(@class, 'btn_secondary') and contains(text(), 'Remove')]")

    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")
    CART_LINK = (By.CLASS_NAME, "shopping_cart_link")

    def sort_by_name_az(self):
        self.click(self.SORT_DROPDOWN)
        self.driver.find_element(By.XPATH, "//option[@value='az']").click()

    def sort_by_price_low_to_high(self):
        self.click(self.SORT_DROPDOWN)
        self.driver.find_element(By.XPATH, "//option[@value='lohi']").click()

    def get_product_names(self):
        elements = self.driver.find_elements(*self.PRODUCT_NAME)
        return [el.text for el in elements]

    def get_product_prices(self):
        elements = self.driver.find_elements(*self.PRODUCT_PRICE)
        return [float(el.text.replace("$", "")) for el in elements]

    def add_first_product_to_cart(self):
        buttons = self.find_all(self.ADD_TO_CART_BUTTONS)
        buttons[0].click()

    def add_all_products_to_cart(self):
        buttons = self.find_all(self.ADD_TO_CART_BUTTONS)
        for button in buttons:
            try:
                button.click()
            except:
                self.driver.execute_script("arguments[0].click();", button)

    def remove_all_from_inventory(self):
        buttons = self.driver.find_elements(*self.REMOVE_BUTTONS)
        for button in buttons:
            button.click()

    def get_cart_badge_count(self):
        try:
            badge = self.find(self.CART_BADGE)
            return int(badge.text)
        except TimeoutException:  # Bây giờ đã nhận diện được
            return 0

    def go_to_cart(self):
        self.click(self.CART_LINK)