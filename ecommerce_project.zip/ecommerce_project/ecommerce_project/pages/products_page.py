from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class ProductsPage(BasePage):
    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")
    CART_BUTTON = (By.CLASS_NAME, "shopping_cart_link")

    def add_product_to_cart_by_name(self, product_name):
        # Dùng xpath chính xác với nút "Add to cart" trong item
        xpath = f"//div[@class='inventory_item']//div[@class='inventory_item_name' and text()='{product_name}']/ancestor::div[@class='inventory_item']//button"
        button = self.wait.until(lambda d: d.find_element(By.XPATH, xpath))
        button.click()

    def get_cart_count(self):
        try:
            return int(self.find(self.CART_BADGE).text)
        except:
            return 0

    def go_to_cart(self):
        self.click(self.CART_BUTTON)
