from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from utils.credentials import VALID_USERNAME, VALID_PASSWORD

class TestAddToCart:

    def test_add_one_product_and_verify_badge_and_cart(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)

        inventory.add_first_product_to_cart()
        assert inventory.get_cart_badge_count() == 1

        inventory.go_to_cart()
        cart = CartPage(driver)
        assert len(cart.get_cart_item_names()) == 1

    def test_add_multiple_products(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)
        inventory.add_all_products_to_cart()
        assert inventory.get_cart_badge_count() == 6