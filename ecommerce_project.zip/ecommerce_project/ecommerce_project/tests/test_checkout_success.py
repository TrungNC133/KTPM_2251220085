from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from utils.credentials import *

class TestCheckoutSuccess:

    def test_complete_checkout_with_valid_info(self, driver):
        # Bước 1: Đăng nhập
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)

        # Bước 2: Thêm 2 sản phẩm
        inv = InventoryPage(driver)
        inv.add_first_product_to_cart()
        inv.driver.find_elements(*inv.ADD_TO_CART_BUTTONS)[1].click()  # thêm cái thứ 2

        # Bước 3: Vào giỏ hàng → Checkout
        inv.go_to_cart()
        CartPage(driver).proceed_to_checkout()

        # Bước 4: Điền thông tin
        checkout = CheckoutPage(driver)
        checkout.fill_shipping_info(CHECKOUT_FIRST_NAME, CHECKOUT_LAST_NAME, CHECKOUT_ZIP)

        # Bước 5: Finish
        checkout.complete_checkout()

        # Bước 6: Kiểm tra thành công
        assert "Thank you for your order!" in checkout.get_success_message()
        assert "complete-header" in checkout.get_success_message().lower()