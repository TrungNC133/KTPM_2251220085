# tests/test_06_checkout_validation.py

import pytest   # ← DÒNG NÀY BỊ THIẾU!

from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from utils.credentials import VALID_USERNAME, VALID_PASSWORD


class TestCheckoutErrorValidation:

    @pytest.mark.parametrize("first,last,zip_code,expected_error", [
        ("", "Nguyen", "700000", "First Name is required"),
        ("John", "", "700000", "Last Name is required"),
        ("John", "Doe", "", "Postal Code is required"),
        ("", "", "", "First Name is required"),
    ])
    def test_checkout_missing_fields(self, driver, first, last, zip_code, expected_error):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        InventoryPage(driver).add_first_product_to_cart()
        InventoryPage(driver).go_to_cart()
        CartPage(driver).proceed_to_checkout()

        checkout = CheckoutPage(driver)
        checkout.fill_shipping_info(first, last, zip_code)
        error_msg = checkout.get_error_message()
        assert expected_error in error_msg