from selenium.webdriver.common.by import By
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from utils.credentials import VALID_USERNAME, VALID_PASSWORD

class TestSorting:

    def test_sort_by_name_a_to_z(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)
        inventory.sort_by_name_az()
        names = inventory.get_product_names()
        assert names == sorted(names)

    def test_sort_by_name_z_to_a(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)
        inventory.find(inventory.SORT_DROPDOWN).click()
        inventory.driver.find_element(By.XPATH, "//option[@value='za']").click()
        names = inventory.get_product_names()
        assert names == sorted(names, reverse=True)

    def test_sort_by_price_low_to_high(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)
        inventory.sort_by_price_low_to_high()
        prices = inventory.get_product_prices()
        assert prices == sorted(prices)

    def test_sort_by_price_high_to_low(self, driver):
        LoginPage(driver).login(VALID_USERNAME, VALID_PASSWORD)
        inventory = InventoryPage(driver)
        inventory.find(inventory.SORT_DROPDOWN).click()
        inventory.driver.find_element(By.XPATH, "//option[@value='hilo']").click()
        prices = inventory.get_product_prices()
        assert prices == sorted(prices, reverse=True)